var ws = new WebSocket("ws://localhost:8000/msg")
ws.onmessage = function(event) {
    console.log("收到了数据:", event.data)
}
