$(document).ready(function() {
    if (!window.console) window.console = {}
    if (!window.console.log) window.console.log = function() {}

    $("#messageform").live("submit", function() {
        newMessage($(this))
        return false
    })
    $("#messageform").live("keypress", function(e) {
        if (e.keyCode == 13) {
            newMessage($(this))
            return false
        }
    })
    $("#message").select()
    updater.start()
})

function newMessage(form) {
    var message = form.formToDict()
    updater.socket.send(JSON.stringify(message))
    $("#message").val("").select();
}

jQuery.fn.formToDict = function() {
    var fields = this.serializeArray()
    var json = {}
    for (var i = 0; i < fields.length; i++) {
        json[fields[i].name] = fields[i].value
    }
    if (json.next) delete json.next
    return json
}

function add(id, txt) {
    var ul = $("#user_list")
    var li = document.createElement("li")
    li.innerHTML = txt
    li.id = id
    ul.append(li)
}

function del(id) {
    $("#" + id).remove()
}

var updater = {
    socket: null,

    start: function() {
        var url = "ws://" + location.host + "/chatsocket"
        updater.socket = new WebSocket(url)
        updater.socket.onmessage = function(event) {
            updater.showMessage(JSON.parse(event.data))
        }
    },

    showMessage: function(message) {
        del(message.client_id)
        if (message.type != "offline") {
            add(message.client_id, message.username)
            if (message.body == "") return
            var existing = $("#m" + message.id)
            if (existing.length > 0) return
            var node = $(message.html)
            node.hide()
            $("#inbox").append(node)
            node.slideDown()
        }
    }
}
